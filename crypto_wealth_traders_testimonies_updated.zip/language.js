(function(){
  const select=document.getElementById('languageSelect');
  if(!select)return;
  const rtl=['ar','fa','he','iw','ur','ps','sd','ug','yi'];
  const originalKey='cwt-original-url';
  const saved=localStorage.getItem('cwt-language')||'en';
  const browser=(navigator.language||'en').toLowerCase();

  function matchBrowser(){
    const b=browser.split('-')[0];
    for(const o of select.options){
      const v=o.value.toLowerCase();
      if(v===browser||v===b)return o.value;
    }
    return 'en';
  }

  function baseUrl(){
    const stored=localStorage.getItem(originalKey);
    if(stored)return stored;
    return window.location.href.split('#')[0];
  }

  function isGoogleTranslatePage(){
    return /(^|\.)translate\.google\./i.test(window.location.hostname) ||
           window.location.pathname.indexOf('/translate')===0;
  }

  function setDirection(code){
    document.documentElement.dir=rtl.includes(code)?'rtl':'ltr';
    document.documentElement.lang=code;
  }

  function translateWithGoogle(code){
    const target=code;
    const source=baseUrl();
    localStorage.setItem('cwt-language',target);
    setDirection(target);
    document.cookie='googtrans=/en/'+target+';path=/;max-age=31536000';

    if(target==='en'){
      localStorage.removeItem(originalKey);
      const url=source;
      window.location.href=url;
      return;
    }

    // Google Translate's hosted translation is used as a reliable fallback
    // for static GitHub Pages sites where the embedded widget may be blocked.
    const translated='https://translate.google.com/translate?sl=en&tl='+encodeURIComponent(target)+'&u='+encodeURIComponent(source);
    window.location.href=translated;
  }

  select.value=saved==='en' ? (localStorage.getItem('cwt-language')||matchBrowser()) : saved;
  if(!select.value)select.value='en';
  setDirection(select.value);

  select.addEventListener('change',function(e){
    const code=e.target.value;
    if(code==='en'){
      localStorage.setItem('cwt-language','en');
      window.location.href=baseUrl();
      return;
    }
    if(!isGoogleTranslatePage()){
      localStorage.setItem(originalKey,window.location.href.split('#')[0]);
    }
    translateWithGoogle(code);
  });
})();
